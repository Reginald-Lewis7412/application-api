
const express = require('express');
const http = require('http');
const https = require('https');
const app = express();
const bodyparser = require('body-parser');
const MongoClient = require('mongodb').MongoClient;
const MONGO_CONNECTION_STRING = 'mongodb+srv://Reginald:Regi123456789@myfoodrecipecluster.uisun.mongodb.net/MyFoodRecipeCluster?retryWrites=true&w=majority';


MongoClient.connect(MONGO_CONNECTION_STRING, {
    useUnifiedTopology: true,
}).then(client => {
console.log('Connected to database');
const db = client.db('food-recipe');
const recipeCollection = db.collection('recipes');

app.set('view engine', 'ejs');

app.use(express.static('public'));

//middleware, need to be put before CRUD operations 
app.use(bodyparser.urlencoded({extended: true}));
app.use(bodyparser.json());

//Add handlers below
app.get('/', (req, res) => {
    db.collection('recipes').find().toArray()
    .then(results => {
        res.render('index.ejs', {recipes: results});
    })
    .catch(error => console.error(error));
    //console.log(cursor);
    //res.sendFile(__dirname + '/index.html');
    
});

app.post('/recipes', (req, res) => {
    if (!req.body.dishName) {
        return res.json({
            success: false,
            message: "You must enter the dishName",
        });
    };
    const newRecipe = {
        dishName: req.body.dishName,
        ingredients: req.body.ingredients,
        recipe: req.body.recipe,
        time: req.body.time,
    };
  recipeCollection.insertOne(newRecipe)
  .then(result => {
      res.redirect('/');
  })
  .catch(error => console.error(error));
});

app.put('/recipes', (req,res) => {
    recipeCollection.findOneAndUpdate(
        {dishName: "onion rings"},
        {
            $set: {
                dishName: req.body.dishName,
                ingredients: req.body.ingredients,
                recipe: req.body.recipe,
                time: req.body.time,
            }
        },
        {
            upsert: true,
        },
    )
    .then(result => {
        res.json('Success');
    })
    .catch(error => console.error(error));
});


//listen to server
app.listen(3002, () => {
    console.log('Listening on port 3002');
});
}).catch(error => console.error(error));



