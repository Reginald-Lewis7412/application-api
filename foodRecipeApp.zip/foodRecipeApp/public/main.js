const updateButton = document.getElementById('update-button');

updateButton.addEventListener('click', (e) => {
    e.preventDefault();
    
    
    const data = {
        id: "5f190371a76a0b52b374794a",
        dishName: 'Updated dishName',
        ingredients: 'Updated ingredients',
        recipe: 'Updated recipe',
        time: 'Updated time'
    };

    fetch('/recipes', {
        method: 'put',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    }).then(res => {
        if (res.ok) return res.json();
    }).then(json => {
       window.location.reload(true);
    });
});